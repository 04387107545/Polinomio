package FILA;
import java.lang.reflect.*;

public class Fila <X> implements Cloneable{
	
	private Object [] elem;
	private int ultimo;

	public Fila (int cap) throws Exception {
		if (cap < 1)
			throw new Exception ("Capacidade n�o permitida para fila");

		this.elem = new Object[cap];
		this.ultimo = -1;
	}

	public void enfilere (X info) throws Exception {
		if(this.cheia())
			throw new Exception ("Fila cheia.");

		this.ultimo++;

		if (info instanceof Cloneable){
			Class<? extends Object> classe = info.getClass();
			Class <?> [] parmsFormais = null;
			Method metodo = classe.getMethod ("clone", parmsFormais);
			Object[] parmsReais = null;
			elem[this.ultimo] = metodo.invoke (info, parmsReais);
		}
		else {
			elem[this.ultimo] = info;
		}
	}

	@SuppressWarnings("unchecked")
	public X desenfilere () throws Exception {
		Object aux = null;

		if (this.ultimo < 0)
			throw new Exception ("N�o h� elementos nesta fila");

		if (this.ultimo >= 0){
			aux = this.elem[0];

			for(int i = 1; i <= this.ultimo; i++){
				this.elem[i-1] = this.elem[i];
			}

			this.elem[this.ultimo] = null;

			this.ultimo--;
		}

		return (X)aux;
	}

	public boolean cheia () {
		if (this.ultimo >= this.elem.length-1)
			return true;

		return false;
	}

	public boolean vazia () {
		if(this.ultimo == -1)
			return true;

		return false;
	}

	public String toString() {
		String ret = "[";

		for (int i = 0; i < this.ultimo; i++){
			ret = ret + this.elem[i] + ", ";
		}

		ret = ret + this.elem[this.ultimo] + "]";

		return ret;
	}

	public int hashCode () {
		int ret = super.hashCode();

		for (int i = 0; i <= this.ultimo; i++){
			ret = ret * 7 + this.elem[i].hashCode();
		}

		return ret;
	}

	public boolean equals (Object obj) {
		if (this==obj)
        return true;

        if (obj==null)
            return false;

        if (!(obj instanceof Fila))
            return false;

        @SuppressWarnings("rawtypes")
		Fila f = (Fila)obj;

        for(int i = 0; i <= this.ultimo; i++){
        	if (this.elem[i] != f.elem[i])
            	return false;
        }

        return true;
	}

	public Fila (Fila <X> modelo) throws Exception {
		if (modelo == null)
			throw new Exception ("Modelo de fila n�o fornecido");

		for (int i = 0; i <= this.ultimo; i++){
			this.elem[i] = modelo.elem[i];
		}
	}

	public Object clone (){
		Object ret = null;

		try{
			ret = new Fila<X>(this);
		}
		catch (Exception erro) {}

		return ret;
	}

}
