package EXPRESSAO;
import java.util.*;
import FILA.Fila;
import PILHA.Pilha;
import TABELA.Tabela;


public class Expressao {
	
	public static void main(String[] args) throws Exception {
		StringTokenizer quebrador = new StringTokenizer ("1+2*3^(6-4+3-2)+5/2+1","+ - * / ^ ()", true);
		
		Double operando1 = null;
		Double operando2 = null;
		String primeiro = null; 
		String operador = null;
		String caracter = null;
		String topo = null;
		Fila<String> fila = new Fila<String>(40);
		Pilha<String> pilha = new Pilha<String>(40);
		
		while (quebrador.hasMoreTokens())
		{
			//System.out.println (quebrador.nextToken());
			
			caracter = quebrador.nextToken();
			
			if(isNumeric(caracter))
			{
				fila.enfilere(caracter);
			}
			else
			{
				if(caracter.equals(")"))
				{
					while(!pilha.vazia())
					{
						topo = pilha.desempilhe();
						
						if(topo.equals("("))
						{							
							break;
						}
						else
						{							
							fila.enfilere(topo);
						}
					}
				}
				else
				{					
					if(pilha.vazia())
					{
						pilha.empilhe(caracter);
					}
					else
					{
						while(!pilha.vazia())
						{
							topo = pilha.topo();
							
							if(Tabela.devoDesempilhar(topo.charAt(0), caracter.charAt(0)))
							{
								pilha.desempilhe();
								fila.enfilere(topo);
							}								
							else
							{							
								break;
							}							
						}
						
						pilha.empilhe(caracter);
				}
			}
		}		
	}
		
		while(!pilha.vazia())
		{
			topo = pilha.topo();
			pilha.desempilhe();
			fila.enfilere(topo);
		}	
		
		while(!fila.vazia())
		{
			primeiro = fila.desenfilere();
			
			if(isNumeric(primeiro))
			{
				pilha.empilhe(primeiro);
			}
			else
			{
				operador = primeiro;
				operando2 = Double.parseDouble(pilha.desempilhe());
				operando1 = Double.parseDouble(pilha.desempilhe());
				
				switch (operador)
				{
					case "+": pilha.empilhe(Double.toString(operando1 + operando2));
					break;
					
					case "-": pilha.empilhe(Double.toString(operando1 - operando2));
					break;
					
					case "*": pilha.empilhe(Double.toString(operando1 * operando2));
					break;
					
					case "/": pilha.empilhe(Double.toString(operando1 / operando2));
					break;
					
					case "^": pilha.empilhe(Double.toString(Math.pow(operando1, operando2)));
					break;
				}
			}
		}
			
		
		System.out.println (pilha.toString());
		
	}

	private static boolean isNumeric(String caracter) {
		// TODO Auto-generated method stub
		return false;
	}

}
