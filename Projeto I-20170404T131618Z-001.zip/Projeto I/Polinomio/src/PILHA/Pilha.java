package PILHA;
import java.lang.reflect.*;

public class Pilha <X> implements Cloneable {
	
	private Object [] elem;
	private int topo;

	public Pilha (int cap) throws Exception {
		if (cap < 1)
			throw new Exception ("capacidade n�o permitida para pilha");

		this.elem = new Object[cap];
		this.topo = -1;
	}

	public void empilhe (X info) throws Exception {
		if (this.cheia())
			throw new Exception ("Pilha cheia.");

		this.topo++;

		if (info instanceof Cloneable){
			Class<? extends Object> classe = info.getClass();
			Class <?> [] parmsFormais = null;
			Method metodo = classe.getMethod ("clone", parmsFormais);
			Object[] parmsReais = null;
			elem[this.topo] = metodo.invoke (info, parmsReais);
		}
		else {
			elem[this.topo] = info;
		}
	}

	@SuppressWarnings("unchecked")
	public X desempilhe () throws Exception {
		Object aux = null;

		if (this.topo < 0)
			throw new Exception ("N�o h� elementos nesta pilha");

		if (this.topo >= 0){
			aux = this.elem[this.topo];
			this.elem[this.topo] = null;
			this.topo--;
		}

		return (X)aux;
	}

	@SuppressWarnings("unchecked")
	public X topo () throws Exception {
		Object aux = null;

		if (this.topo < 0)
			throw new Exception ("N�o h� elementos nesta pilha");

		if (this.topo >= 0){
			aux = this.elem[this.topo];
		}

		return (X)aux;
	}
	
	public boolean cheia () {
		if (this.topo == this.elem.length-1)
			return true;
		else
			return false;
	}

	public boolean vazia () {
		if(this.topo == -1)
			return true;

		return false;

	}

	public String toString() {
		String ret = "---";

		for (int i = this.topo; i >= 0; i--){
			ret = ret + this.elem[i] + "---";
		}

		return ret;
	}

	public int hashCode () {
		int ret = super.hashCode();

		for(int i = 0; i<=this.topo; i++){
			ret = ret * 7 + this.elem[i].hashCode();
		}

		return ret;
	}

	public boolean equals (Object obj) {
		if (this==obj)
        return true;

        if (obj==null)
            return false;

        if (!(obj instanceof Pilha))
            return false;

        @SuppressWarnings("rawtypes")
		Pilha p = (Pilha)obj; //atrav�s dos IF's anteriores viu-se que obj � mon�mio. Logo, for�amos o JAVA a exergar ele como mon�mio

        for(int i = 0; i <= this.topo; i++){
        	if (this.elem[i] != p.elem[i])
            	return false;
        }

        return true;

	}

	public Pilha (Pilha <X> modelo) throws Exception {
		if (modelo == null)
			throw new Exception ("Objeto n�o fornecido");
		
		for (int i = 0; i <= this.topo; i++){
			this.elem[i] = modelo.elem[i];
		}
	}

	public Object clone (){
		Object ret = null;

		try{
			ret = new Pilha<X> (this);
		}
		catch (Exception erro) {}

		return ret;
	}

}
