1 + 2 * 3 / 4 ^ ( 5 - 2 + 1) + 1

FALSE -> N�o tiro e coloco.
TRUE ->  Tiro e coloco


public class Tabela{

      private char[] vetor = {'(','^','*','/','+','-',')'};
      private boolean[] [] tabela = {{false,false,false,false,false,false,true},
                                    {false,true,true,true,true,true,true}
                                    {false,false,true,true,true,true,true}
                                    {false,false,true,true,true,true,true}
                                    {false,false,false,false,true,true,true}
                                    {false,false,false,false,true,true,true}
                                    {false,false,false,false,false,false,false}};

      public char QuebrarString ()
      {
        StringTokenizer quebrador = new StringTokenizer (exp, "+-*/^()", true);


      }

         public int Empilhar (int x)
        {
          int object[] vetor;
          int topo = -1;

         if(topo==null) // Se a pilha se encontra vazia

            this.topo ++; // Insere valor no topo
            this.vetor[this.topo] = x; // A string passada pelo usu�rio est� presente no vetor que vai ser empilhada, "x" representa o "carctere" da string                                       //passado por par�metro no m�todo empilhar.
    
         if(topo==this.topo[x]) // Se existe algum operador no topo
           
          
           this.vetor = new vetor [this.tabela [] []];

      public boolean Desempilhar (char linha, char coluna)
      { 
         
      }
}